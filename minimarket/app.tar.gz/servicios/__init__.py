# -*- coding: utf-8 -*-
# Esta carpeta tiene la "lógica" del minimarket: iniciar sesión,
# productos, clientes, ventas y reportes (logica.py).
