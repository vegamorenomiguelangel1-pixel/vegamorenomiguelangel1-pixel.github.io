# -*- coding: utf-8 -*-
"""
logica.py
---------
Aquí está la "cocina" del minimarket: el código que hace el trabajo real.

La interfaz (el menú de la terminal ahora, y más adelante la pantalla en Flet)
solo llama a estas funciones. Así no hay que repetir la lógica.

Qué puedes hacer desde aquí:
- iniciar sesión
- saber si un rol tiene permiso para una acción
- productos (listar, crear, editar, borrar)
- clientes (listar, crear, editar, borrar)
- registrar una venta (descuenta el stock)
- reportes del día
- crear un usuario nuevo (solo el admin)
"""

from datetime import datetime  # para poner la fecha y hora de cada venta

from datos.base_datos import (
    conectar,
    fila_a_diccionario,
    generar_sal,
    hashear_clave,
)


class ErrorMinimarket(Exception):
    """
    Un error del programa con un mensaje claro en español.
    Ejemplo: "No hay suficiente stock del producto Arroz 1 kg."
    """
    pass


# Acciones que puede hacer cada rol.
# El admin puede todo. El cajero solo vende, mira productos y ve/crea clientes.
PERMISOS_CAJERO = {
    "ver_productos",
    "ver_clientes",
    "crear_cliente",
    "vender",
}


def permiso(rol, accion):
    """
    Devuelve True si ese rol puede hacer esa acción.
    rol: "admin" o "cajero"
    accion: por ejemplo "crear_producto" o "vender"
    """
    if rol == "admin":
        return True  # el administrador puede hacer de todo
    if rol == "cajero":
        return accion in PERMISOS_CAJERO
    return False  # un rol desconocido no tiene permiso


def exigir_permiso(usuario_actual, accion):
    """Si la persona no tiene permiso, corta el proceso con un mensaje claro."""
    rol = usuario_actual.get("rol") if usuario_actual else None
    if not permiso(rol, accion):
        raise ErrorMinimarket(
            "No tienes permiso para hacer esto. Tu rol es: "
            f"{rol or 'desconocido'}."
        )


def login(usuario, clave):
    """
    Revisa si el usuario y la contraseña son correctos.
    Si todo está bien, devuelve un diccionario con los datos (incluye el rol).
    Si algo falla (clave mala, usuario que no existe, cuenta inactiva),
    devuelve None.
    """
    if not usuario or not clave:
        return None

    conexion = conectar()
    try:
        fila = conexion.execute(
            """
            SELECT u.id, u.usuario, u.sal, u.clave_hash, u.nombre,
                   u.activo, r.nombre AS rol, u.rol_id
            FROM usuarios u
            JOIN roles r ON r.id = u.rol_id
            WHERE u.usuario = ?
            """,
            (usuario.strip(),),
        ).fetchone()

        if fila is None:
            return None  # ese nombre de usuario no existe

        if fila["activo"] != 1:
            return None  # la cuenta está desactivada

        # Recalculamos la huella con la sal guardada y la clave que escribió
        huella = hashear_clave(clave, fila["sal"])
        if huella != fila["clave_hash"]:
            return None  # la contraseña no coincide

        # Armamos el diccionario que usará el resto del programa
        return {
            "id": fila["id"],
            "usuario": fila["usuario"],
            "nombre": fila["nombre"],
            "rol": fila["rol"],
            "rol_id": fila["rol_id"],
            "activo": fila["activo"],
        }
    finally:
        conexion.close()


# ---------------------------------------------------------------------------
# Productos
# ---------------------------------------------------------------------------

def listar_productos():
    """Devuelve la lista de todos los productos, ordenados por nombre."""
    conexion = conectar()
    try:
        filas = conexion.execute(
            "SELECT * FROM productos ORDER BY nombre"
        ).fetchall()
        return [fila_a_diccionario(f) for f in filas]
    finally:
        conexion.close()


def obtener_producto(producto_id=None, codigo=None):
    """Busca un producto por su id o por su código. Si no está, devuelve None."""
    if producto_id is None and not codigo:
        return None
    conexion = conectar()
    try:
        if producto_id is not None:
            fila = conexion.execute(
                "SELECT * FROM productos WHERE id = ?", (producto_id,)
            ).fetchone()
        else:
            fila = conexion.execute(
                "SELECT * FROM productos WHERE codigo = ?", (codigo.strip(),)
            ).fetchone()
        return fila_a_diccionario(fila)
    finally:
        conexion.close()


def _validar_datos_producto(codigo, nombre, precio, stock, stock_minimo):
    """Revisa que los datos del producto tengan sentido. Si no, lanza un error."""
    if not codigo or not str(codigo).strip():
        raise ErrorMinimarket("El código del producto no puede estar vacío.")
    if not nombre or not str(nombre).strip():
        raise ErrorMinimarket("El nombre del producto no puede estar vacío.")
    try:
        precio = float(precio)
        stock = int(stock)
        stock_minimo = int(stock_minimo)
    except (TypeError, ValueError):
        raise ErrorMinimarket(
            "El precio, el stock y el stock mínimo deben ser números."
        )
    if precio < 0:
        raise ErrorMinimarket("El precio no puede ser negativo.")
    if stock < 0:
        raise ErrorMinimarket("El stock no puede ser negativo.")
    if stock_minimo < 0:
        raise ErrorMinimarket("El stock mínimo no puede ser negativo.")
    return str(codigo).strip(), str(nombre).strip(), precio, stock, stock_minimo


def crear_producto(usuario_actual, codigo, nombre, categoria, precio, stock, stock_minimo=5):
    """
    Agrega un producto nuevo. Solo el administrador puede hacerlo.
    Devuelve el producto recién creado (con su id).
    """
    exigir_permiso(usuario_actual, "crear_producto")
    codigo, nombre, precio, stock, stock_minimo = _validar_datos_producto(
        codigo, nombre, precio, stock, stock_minimo
    )
    categoria = (categoria or "").strip()

    conexion = conectar()
    try:
        # El código tiene que ser único (como el código de barras)
        ya_existe = conexion.execute(
            "SELECT id FROM productos WHERE codigo = ?", (codigo,)
        ).fetchone()
        if ya_existe:
            raise ErrorMinimarket(
                f"Ya existe un producto con el código {codigo}."
            )

        cursor = conexion.execute(
            """
            INSERT INTO productos (codigo, nombre, categoria, precio, stock, stock_minimo)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (codigo, nombre, categoria, precio, stock, stock_minimo),
        )
        conexion.commit()
        return obtener_producto(producto_id=cursor.lastrowid)
    except ErrorMinimarket:
        conexion.rollback()
        raise
    finally:
        conexion.close()


def actualizar_producto(usuario_actual, producto_id, codigo, nombre, categoria, precio, stock, stock_minimo):
    """Cambia los datos de un producto. Solo el administrador puede hacerlo."""
    exigir_permiso(usuario_actual, "editar_producto")
    codigo, nombre, precio, stock, stock_minimo = _validar_datos_producto(
        codigo, nombre, precio, stock, stock_minimo
    )
    categoria = (categoria or "").strip()

    if obtener_producto(producto_id=producto_id) is None:
        raise ErrorMinimarket("No se encontró ese producto.")

    conexion = conectar()
    try:
        # Que el código nuevo no esté usado por OTRO producto
        conflicto = conexion.execute(
            "SELECT id FROM productos WHERE codigo = ? AND id <> ?",
            (codigo, producto_id),
        ).fetchone()
        if conflicto:
            raise ErrorMinimarket(
                f"Ya existe otro producto con el código {codigo}."
            )

        conexion.execute(
            """
            UPDATE productos
            SET codigo = ?, nombre = ?, categoria = ?, precio = ?,
                stock = ?, stock_minimo = ?
            WHERE id = ?
            """,
            (codigo, nombre, categoria, precio, stock, stock_minimo, producto_id),
        )
        conexion.commit()
        return obtener_producto(producto_id=producto_id)
    except ErrorMinimarket:
        conexion.rollback()
        raise
    finally:
        conexion.close()


def eliminar_producto(usuario_actual, producto_id):
    """
    Borra un producto. Solo el administrador puede hacerlo.
    Si el producto ya se usó en una venta, no se puede borrar
    (la base de datos lo protege).
    """
    exigir_permiso(usuario_actual, "eliminar_producto")
    if obtener_producto(producto_id=producto_id) is None:
        raise ErrorMinimarket("No se encontró ese producto.")

    conexion = conectar()
    try:
        conexion.execute("DELETE FROM productos WHERE id = ?", (producto_id,))
        conexion.commit()
    except Exception:
        conexion.rollback()
        raise ErrorMinimarket(
            "No se puede borrar este producto porque ya se usó en una venta."
        )
    finally:
        conexion.close()


# ---------------------------------------------------------------------------
# Clientes
# ---------------------------------------------------------------------------

def listar_clientes():
    """Devuelve la lista de todos los clientes, ordenados por nombre."""
    conexion = conectar()
    try:
        filas = conexion.execute(
            "SELECT * FROM clientes ORDER BY nombre"
        ).fetchall()
        return [fila_a_diccionario(f) for f in filas]
    finally:
        conexion.close()


def obtener_cliente(cliente_id):
    """Busca un cliente por su id. Si no está, devuelve None."""
    conexion = conectar()
    try:
        fila = conexion.execute(
            "SELECT * FROM clientes WHERE id = ?", (cliente_id,)
        ).fetchone()
        return fila_a_diccionario(fila)
    finally:
        conexion.close()


def crear_cliente(usuario_actual, nombre, ci_nit="", telefono=""):
    """
    Agrega un cliente nuevo. Lo pueden hacer el admin y el cajero.
    Devuelve el cliente recién creado.
    """
    exigir_permiso(usuario_actual, "crear_cliente")
    nombre = (nombre or "").strip()
    if not nombre:
        raise ErrorMinimarket("El nombre del cliente no puede estar vacío.")
    ci_nit = (ci_nit or "").strip()
    telefono = (telefono or "").strip()

    conexion = conectar()
    try:
        cursor = conexion.execute(
            """
            INSERT INTO clientes (nombre, ci_nit, telefono)
            VALUES (?, ?, ?)
            """,
            (nombre, ci_nit, telefono),
        )
        conexion.commit()
        return obtener_cliente(cursor.lastrowid)
    finally:
        conexion.close()


def actualizar_cliente(usuario_actual, cliente_id, nombre, ci_nit="", telefono=""):
    """Cambia los datos de un cliente. Solo el administrador puede hacerlo."""
    exigir_permiso(usuario_actual, "editar_cliente")
    nombre = (nombre or "").strip()
    if not nombre:
        raise ErrorMinimarket("El nombre del cliente no puede estar vacío.")
    if obtener_cliente(cliente_id) is None:
        raise ErrorMinimarket("No se encontró ese cliente.")

    conexion = conectar()
    try:
        conexion.execute(
            """
            UPDATE clientes
            SET nombre = ?, ci_nit = ?, telefono = ?
            WHERE id = ?
            """,
            (nombre, (ci_nit or "").strip(), (telefono or "").strip(), cliente_id),
        )
        conexion.commit()
        return obtener_cliente(cliente_id)
    finally:
        conexion.close()


def eliminar_cliente(usuario_actual, cliente_id):
    """
    Borra un cliente. Solo el administrador puede hacerlo.
    Si el cliente ya tiene ventas, no se puede borrar.
    """
    exigir_permiso(usuario_actual, "eliminar_cliente")
    if obtener_cliente(cliente_id) is None:
        raise ErrorMinimarket("No se encontró ese cliente.")

    conexion = conectar()
    try:
        conexion.execute("DELETE FROM clientes WHERE id = ?", (cliente_id,))
        conexion.commit()
    except Exception:
        conexion.rollback()
        raise ErrorMinimarket(
            "No se puede borrar este cliente porque ya tiene ventas registradas."
        )
    finally:
        conexion.close()


# ---------------------------------------------------------------------------
# Ventas
# ---------------------------------------------------------------------------

def _normalizar_item(item):
    """
    Deja cada renglón de la venta en un formato igual:
    {'producto_id': int, 'cantidad': int}
    Se puede pasar el id o el código del producto.
    """
    if not isinstance(item, dict):
        raise ErrorMinimarket("Cada ítem de la venta debe ser un diccionario.")

    cantidad = item.get("cantidad")
    try:
        cantidad = int(cantidad)
    except (TypeError, ValueError):
        raise ErrorMinimarket("La cantidad debe ser un número entero.")
    if cantidad <= 0:
        raise ErrorMinimarket("La cantidad debe ser mayor que cero.")

    producto_id = item.get("producto_id")
    codigo = item.get("codigo")
    if producto_id is None and not codigo:
        raise ErrorMinimarket("Cada ítem necesita un producto_id o un código.")

    if producto_id is None:
        producto = obtener_producto(codigo=codigo)
        if producto is None:
            raise ErrorMinimarket(f"No existe un producto con el código {codigo}.")
        producto_id = producto["id"]

    return {"producto_id": int(producto_id), "cantidad": cantidad}


def registrar_venta(usuario_id, cliente_id, items):
    """
    Registra una venta completa.

    usuario_id: quién está vendiendo (el id del usuario que inició sesión)
    cliente_id: el cliente (puede ser None si es consumidor final)
    items: lista de diccionarios, por ejemplo:
           [{"producto_id": 1, "cantidad": 2}, {"codigo": "ARZ001", "cantidad": 1}]

    Qué hace, todo en una sola transacción (o se guarda todo, o no se guarda nada):
    1. Revisa que haya stock suficiente de cada producto.
    2. Guarda la venta y sus renglones.
    3. Descuenta el stock.
    4. Devuelve la venta con su detalle y el total.

    Si falta stock o hay un error, no se guarda nada y se lanza ErrorMinimarket.
    """
    if not items:
        raise ErrorMinimarket("La venta no tiene productos. Agrega al menos uno.")

    # Confirmamos que el vendedor exista y esté activo
    conexion = conectar()
    try:
        vendedor = conexion.execute(
            "SELECT id, activo FROM usuarios WHERE id = ?", (usuario_id,)
        ).fetchone()
        if vendedor is None or vendedor["activo"] != 1:
            raise ErrorMinimarket("El usuario que vende no existe o está inactivo.")

        if cliente_id is not None:
            cliente = conexion.execute(
                "SELECT id FROM clientes WHERE id = ?", (cliente_id,)
            ).fetchone()
            if cliente is None:
                raise ErrorMinimarket("No se encontró ese cliente.")

        # Unificamos los ítems (si el mismo producto aparece dos veces, sumamos)
        acumulado = {}
        for crudo in items:
            item = _normalizar_item(crudo)
            pid = item["producto_id"]
            acumulado[pid] = acumulado.get(pid, 0) + item["cantidad"]

        # Revisamos stock y armamos los renglones con el precio actual
        renglones = []
        for producto_id, cantidad in acumulado.items():
            producto = conexion.execute(
                "SELECT * FROM productos WHERE id = ?", (producto_id,)
            ).fetchone()
            if producto is None:
                raise ErrorMinimarket(
                    f"No se encontró el producto con id {producto_id}."
                )
            if producto["stock"] < cantidad:
                raise ErrorMinimarket(
                    "No hay suficiente stock del producto "
                    f"'{producto['nombre']}'. Hay {producto['stock']} "
                    f"y se pidieron {cantidad}."
                )
            precio = float(producto["precio"])
            subtotal = round(precio * cantidad, 2)
            renglones.append(
                {
                    "producto_id": producto_id,
                    "nombre": producto["nombre"],
                    "codigo": producto["codigo"],
                    "cantidad": cantidad,
                    "precio_unitario": precio,
                    "subtotal": subtotal,
                    "stock_actual": producto["stock"],
                }
            )

        total = round(sum(r["subtotal"] for r in renglones), 2)
        fecha = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # A partir de aquí, o se guarda TODO o se cancela TODO (rollback)
        cursor = conexion.execute(
            """
            INSERT INTO ventas (fecha, cliente_id, usuario_id, total)
            VALUES (?, ?, ?, ?)
            """,
            (fecha, cliente_id, usuario_id, total),
        )
        venta_id = cursor.lastrowid

        for r in renglones:
            conexion.execute(
                """
                INSERT INTO detalle_venta
                    (venta_id, producto_id, cantidad, precio_unitario, subtotal)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    venta_id,
                    r["producto_id"],
                    r["cantidad"],
                    r["precio_unitario"],
                    r["subtotal"],
                ),
            )
            # Descontamos el stock
            conexion.execute(
                "UPDATE productos SET stock = stock - ? WHERE id = ?",
                (r["cantidad"], r["producto_id"]),
            )

        conexion.commit()

        return obtener_venta(venta_id)
    except ErrorMinimarket:
        conexion.rollback()
        raise
    except Exception:
        conexion.rollback()
        raise
    finally:
        conexion.close()


def obtener_venta(venta_id):
    """Devuelve una venta con su detalle (los productos que se vendieron)."""
    conexion = conectar()
    try:
        venta = conexion.execute(
            """
            SELECT v.id, v.fecha, v.cliente_id, v.usuario_id, v.total,
                   c.nombre AS cliente_nombre,
                   u.usuario AS usuario_nombre
            FROM ventas v
            LEFT JOIN clientes c ON c.id = v.cliente_id
            JOIN usuarios u ON u.id = v.usuario_id
            WHERE v.id = ?
            """,
            (venta_id,),
        ).fetchone()
        if venta is None:
            return None

        detalles = conexion.execute(
            """
            SELECT d.id, d.producto_id, d.cantidad, d.precio_unitario, d.subtotal,
                   p.codigo, p.nombre
            FROM detalle_venta d
            JOIN productos p ON p.id = d.producto_id
            WHERE d.venta_id = ?
            ORDER BY d.id
            """,
            (venta_id,),
        ).fetchall()

        resultado = fila_a_diccionario(venta)
        resultado["detalle"] = [fila_a_diccionario(d) for d in detalles]
        return resultado
    finally:
        conexion.close()


# ---------------------------------------------------------------------------
# Reportes
# ---------------------------------------------------------------------------

def _fecha_dia(fecha=None):
    """Si no nos pasan una fecha, usamos el día de hoy (formato YYYY-MM-DD)."""
    if fecha:
        return fecha
    return datetime.now().strftime("%Y-%m-%d")


def ventas_del_dia(fecha=None):
    """Lista las ventas de un día (por defecto, hoy)."""
    dia = _fecha_dia(fecha)
    conexion = conectar()
    try:
        filas = conexion.execute(
            """
            SELECT v.id, v.fecha, v.cliente_id, v.usuario_id, v.total,
                   c.nombre AS cliente_nombre,
                   u.usuario AS usuario_nombre
            FROM ventas v
            LEFT JOIN clientes c ON c.id = v.cliente_id
            JOIN usuarios u ON u.id = v.usuario_id
            WHERE v.fecha LIKE ?
            ORDER BY v.fecha
            """,
            (dia + "%",),
        ).fetchall()
        return [fila_a_diccionario(f) for f in filas]
    finally:
        conexion.close()


def total_vendido(fecha=None):
    """Suma el total de bolivianos vendidos en un día (por defecto, hoy)."""
    dia = _fecha_dia(fecha)
    conexion = conectar()
    try:
        fila = conexion.execute(
            """
            SELECT COALESCE(SUM(total), 0) AS total
            FROM ventas
            WHERE fecha LIKE ?
            """,
            (dia + "%",),
        ).fetchone()
        return round(float(fila["total"]), 2)
    finally:
        conexion.close()


def productos_mas_vendidos(limite=5):
    """
    Devuelve los productos que más se han vendido (por cantidad),
    de mayor a menor. 'limite' es cuántos quieres ver (por defecto 5).
    """
    conexion = conectar()
    try:
        filas = conexion.execute(
            """
            SELECT p.id, p.codigo, p.nombre,
                   SUM(d.cantidad) AS cantidad_vendida,
                   ROUND(SUM(d.subtotal), 2) AS total
            FROM detalle_venta d
            JOIN productos p ON p.id = d.producto_id
            GROUP BY p.id, p.codigo, p.nombre
            ORDER BY cantidad_vendida DESC
            LIMIT ?
            """,
            (int(limite),),
        ).fetchall()
        return [fila_a_diccionario(f) for f in filas]
    finally:
        conexion.close()


def productos_stock_bajo():
    """
    Lista los productos cuyo stock está en el mínimo o más abajo.
    Sirve para saber qué hay que reponer.
    """
    conexion = conectar()
    try:
        filas = conexion.execute(
            """
            SELECT * FROM productos
            WHERE stock <= stock_minimo
            ORDER BY stock ASC, nombre
            """
        ).fetchall()
        return [fila_a_diccionario(f) for f in filas]
    finally:
        conexion.close()


# ---------------------------------------------------------------------------
# Usuarios (solo el administrador crea cuentas nuevas)
# ---------------------------------------------------------------------------

def crear_usuario(usuario_actual, usuario, clave, nombre, rol):
    """
    Crea una cuenta nueva. Solo el administrador puede hacerlo.
    rol debe ser "admin" o "cajero".
    Devuelve el usuario creado (sin la contraseña).
    """
    exigir_permiso(usuario_actual, "crear_usuario")

    usuario = (usuario or "").strip()
    nombre = (nombre or "").strip()
    rol = (rol or "").strip().lower()

    if not usuario:
        raise ErrorMinimarket("El nombre de usuario no puede estar vacío.")
    if not clave:
        raise ErrorMinimarket("La contraseña no puede estar vacía.")
    if not nombre:
        raise ErrorMinimarket("El nombre de la persona no puede estar vacío.")
    if rol not in ("admin", "cajero"):
        raise ErrorMinimarket("El rol debe ser 'admin' o 'cajero'.")

    conexion = conectar()
    try:
        ya = conexion.execute(
            "SELECT id FROM usuarios WHERE usuario = ?", (usuario,)
        ).fetchone()
        if ya:
            raise ErrorMinimarket(f"Ya existe un usuario llamado '{usuario}'.")

        rol_fila = conexion.execute(
            "SELECT id FROM roles WHERE nombre = ?", (rol,)
        ).fetchone()
        if rol_fila is None:
            raise ErrorMinimarket(f"No existe el rol '{rol}'.")

        sal = generar_sal()
        cursor = conexion.execute(
            """
            INSERT INTO usuarios (usuario, sal, clave_hash, nombre, rol_id, activo)
            VALUES (?, ?, ?, ?, ?, 1)
            """,
            (usuario, sal, hashear_clave(clave, sal), nombre, rol_fila["id"]),
        )
        conexion.commit()
        nuevo_id = cursor.lastrowid
        fila = conexion.execute(
            """
            SELECT u.id, u.usuario, u.nombre, r.nombre AS rol, u.activo
            FROM usuarios u
            JOIN roles r ON r.id = u.rol_id
            WHERE u.id = ?
            """,
            (nuevo_id,),
        ).fetchone()
        return fila_a_diccionario(fila)
    except ErrorMinimarket:
        conexion.rollback()
        raise
    finally:
        conexion.close()


def listar_usuarios(usuario_actual):
    """Lista las cuentas (sin contraseñas). Solo el administrador."""
    exigir_permiso(usuario_actual, "ver_usuarios")
    conexion = conectar()
    try:
        filas = conexion.execute(
            """
            SELECT u.id, u.usuario, u.nombre, r.nombre AS rol, u.activo
            FROM usuarios u
            JOIN roles r ON r.id = u.rol_id
            ORDER BY u.usuario
            """
        ).fetchall()
        return [fila_a_diccionario(f) for f in filas]
    finally:
        conexion.close()
