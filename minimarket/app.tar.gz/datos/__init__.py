# -*- coding: utf-8 -*-
# Esta carpeta guarda la base de datos (minimarket.db) y el archivo
# que sabe cómo abrirla y crear las tablas (base_datos.py).
