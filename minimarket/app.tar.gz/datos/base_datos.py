# -*- coding: utf-8 -*-
"""
base_datos.py
-------------
Este archivo se encarga de la base de datos del minimarket.

Piensa en la base de datos como un cuaderno bien organizado:
aquí guardamos usuarios, productos, clientes y ventas.

Usamos SQLite, que guarda todo en un solo archivo llamado minimarket.db
(queda en esta misma carpeta, datos/). No hace falta instalar un servidor.
"""

import hashlib  # para "envolver" la contraseña y no guardarla en texto plano
import os       # para armar la ruta del archivo de la base de datos
import sqlite3  # la librería de Python que habla con SQLite
import sys      # para detectar si corremos en el navegador (Pyodide)


# Si en las pruebas queremos usar otro archivo, aquí se guarda esa ruta.
# Si vale None, se usa el archivo normal: minimarket.db
_ruta_personalizada = None


def obtener_ruta_db():
    """Devuelve la ruta del archivo .db que vamos a usar."""
    if _ruta_personalizada:
        return _ruta_personalizada
    # En el navegador (Pyodide) no siempre se puede escribir junto al código.
    # Probamos carpetas que sí suelen ser escribibles y, si no, usamos datos/.
    if sys.platform == "emscripten":
        for carpeta_ok in ("/home/web_user", "/home/pyodide", "/tmp"):
            if os.path.isdir(carpeta_ok) and os.access(carpeta_ok, os.W_OK):
                return os.path.join(carpeta_ok, "minimarket.db")
    # os.path.abspath(__file__) = la ruta completa de este archivo base_datos.py
    # os.path.dirname(...) = la carpeta donde está ese archivo
    carpeta = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(carpeta, "minimarket.db")


def configurar_ruta_db(ruta):
    """Cambia el archivo .db (sirve para las pruebas, para no ensuciar el real)."""
    global _ruta_personalizada
    _ruta_personalizada = ruta


def generar_sal():
    """Crea un texto aleatorio (la 'sal') para que cada contraseña se guarde distinto."""
    # 16 bytes al azar, pasados a hexadecimal (queda un texto de 32 letras/números)
    return os.urandom(16).hex()


def hashear_clave(clave, sal):
    """
    Junta la sal y la contraseña, y saca una 'huella' con SHA-256.
    Así no guardamos la contraseña tal cual: aunque alguien abra el .db,
    no ve la clave original.
    """
    texto = sal + clave
    return hashlib.sha256(texto.encode("utf-8")).hexdigest()


def conectar():
    """
    Abre la conexión con la base de datos.
    Es como abrir el cuaderno para leer o escribir.
    Recuerda cerrarla cuando termines (conexion.close()).
    """
    conexion = sqlite3.connect(obtener_ruta_db())
    # Así podemos leer las filas como diccionario: fila["nombre"] en vez de fila[0]
    conexion.row_factory = sqlite3.Row
    # Activa las claves foráneas: no se puede, por ejemplo, borrar un producto
    # que ya se usó en una venta.
    conexion.execute("PRAGMA foreign_keys = ON")
    return conexion


def _crear_tablas(conexion):
    """Crea las tablas si todavía no existen. No borra datos que ya estén."""
    cursor = conexion.cursor()

    # Tabla de roles: "admin" y "cajero"
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS roles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT UNIQUE NOT NULL
        )
    """)

    # Tabla de usuarios: quién puede entrar al sistema
    # sal y clave_hash guardan la contraseña de forma segura
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario TEXT UNIQUE NOT NULL,
            sal TEXT NOT NULL,
            clave_hash TEXT NOT NULL,
            nombre TEXT NOT NULL,
            rol_id INTEGER NOT NULL,
            activo INTEGER NOT NULL DEFAULT 1,
            FOREIGN KEY (rol_id) REFERENCES roles(id)
        )
    """)

    # Tabla de productos: lo que se vende en el minimarket
    # precio está en bolivianos (Bs) y es REAL (puede tener decimales, como 8.50)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS productos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo TEXT UNIQUE NOT NULL,
            nombre TEXT NOT NULL,
            categoria TEXT,
            precio REAL NOT NULL,
            stock INTEGER NOT NULL DEFAULT 0,
            stock_minimo INTEGER NOT NULL DEFAULT 5
        )
    """)

    # Tabla de clientes: compradores frecuentes
    # ci_nit puede ser cédula de identidad o NIT
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            ci_nit TEXT,
            telefono TEXT
        )
    """)

    # Tabla de ventas: cada ticket / factura
    # cliente_id puede quedar vacío (venta a "consumidor final")
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS ventas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TEXT NOT NULL,
            cliente_id INTEGER,
            usuario_id INTEGER NOT NULL,
            total REAL NOT NULL,
            FOREIGN KEY (cliente_id) REFERENCES clientes(id),
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        )
    """)

    # Tabla de detalle_venta: cada renglón de una venta (producto + cantidad)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS detalle_venta (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            venta_id INTEGER NOT NULL,
            producto_id INTEGER NOT NULL,
            cantidad INTEGER NOT NULL,
            precio_unitario REAL NOT NULL,
            subtotal REAL NOT NULL,
            FOREIGN KEY (venta_id) REFERENCES ventas(id),
            FOREIGN KEY (producto_id) REFERENCES productos(id)
        )
    """)

    conexion.commit()


def _esta_vacia(conexion, tabla):
    """Devuelve True si la tabla no tiene ninguna fila todavía."""
    cursor = conexion.execute(f"SELECT COUNT(*) AS cantidad FROM {tabla}")
    return cursor.fetchone()["cantidad"] == 0


def _sembrar_datos(conexion):
    """
    Si las tablas están vacías, pone datos de ejemplo para poder probar el programa.
    Si ya hay datos, no toca nada (así no borramos lo que tú hayas cargado).
    """
    cursor = conexion.cursor()

    # Roles por defecto
    if _esta_vacia(conexion, "roles"):
        cursor.execute("INSERT INTO roles (nombre) VALUES ('admin')")
        cursor.execute("INSERT INTO roles (nombre) VALUES ('cajero')")

    # Usuarios de ejemplo (solo si no hay ningún usuario)
    # Usuario: admin   Contraseña: admin123
    # Usuario: cajero  Contraseña: cajero123
    if _esta_vacia(conexion, "usuarios"):
        cursor.execute("SELECT id, nombre FROM roles")
        roles = {fila["nombre"]: fila["id"] for fila in cursor.fetchall()}

        sal_admin = generar_sal()
        cursor.execute(
            """
            INSERT INTO usuarios (usuario, sal, clave_hash, nombre, rol_id, activo)
            VALUES (?, ?, ?, ?, ?, 1)
            """,
            (
                "admin",
                sal_admin,
                hashear_clave("admin123", sal_admin),
                "Administrador",
                roles["admin"],
            ),
        )

        sal_cajero = generar_sal()
        cursor.execute(
            """
            INSERT INTO usuarios (usuario, sal, clave_hash, nombre, rol_id, activo)
            VALUES (?, ?, ?, ?, ?, 1)
            """,
            (
                "cajero",
                sal_cajero,
                hashear_clave("cajero123", sal_cajero),
                "Cajero",
                roles["cajero"],
            ),
        )

    # Algunos productos de ejemplo (precios en bolivianos)
    if _esta_vacia(conexion, "productos"):
        productos = [
            # codigo, nombre, categoria, precio, stock, stock_minimo
            ("ARZ001", "Arroz 1 kg", "Alimentos", 8.50, 50, 10),
            ("ACE001", "Aceite 900 ml", "Alimentos", 15.00, 30, 8),
            ("AZU001", "Azúcar 1 kg", "Alimentos", 7.00, 40, 10),
            ("LEC001", "Leche 1 L", "Lácteos", 9.50, 25, 8),
            ("JAB001", "Jabón de tocador", "Limpieza", 4.50, 20, 5),
            # Este tiene poco stock a propósito, para probar la alerta de stock bajo
            ("GAL001", "Galletas surtidas", "Snacks", 3.00, 4, 8),
        ]
        cursor.executemany(
            """
            INSERT INTO productos (codigo, nombre, categoria, precio, stock, stock_minimo)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            productos,
        )

    # Algunos clientes de ejemplo
    if _esta_vacia(conexion, "clientes"):
        clientes = [
            ("María López", "1234567", "70000001"),
            ("Juan Pérez", "7654321", "70000002"),
            ("Ana Gutiérrez", "1122334", "70000003"),
        ]
        cursor.executemany(
            """
            INSERT INTO clientes (nombre, ci_nit, telefono)
            VALUES (?, ?, ?)
            """,
            clientes,
        )

    conexion.commit()


def inicializar():
    """
    Prepara la base de datos: crea el archivo si no existe,
    arma las tablas y, si están vacías, carga los datos de ejemplo.
    Llama a esta función al arrancar el programa.
    """
    conexion = conectar()
    try:
        _crear_tablas(conexion)
        _sembrar_datos(conexion)
    finally:
        conexion.close()


def fila_a_diccionario(fila):
    """Convierte una fila de SQLite en un diccionario normal de Python."""
    if fila is None:
        return None
    return dict(fila)
