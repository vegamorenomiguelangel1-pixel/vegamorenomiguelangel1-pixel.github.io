# -*- coding: utf-8 -*-
"""
app_flet.py
-----------
Interfaz visual del minimarket, hecha con Flet 1.x.

No habla directo con la base de datos: llama a las funciones de logica.py.
Así, si más adelante cambiamos la pantalla, el cerebro del programa
(la lógica y SQLite) se queda igual.

Pantallas:
  1. Inicio de sesión (usuario y contraseña).
  2. Menú según el rol:
       - admin: Inicio, Productos, Clientes, Ventas, Reportes, Usuarios
       - cajero: Ventas, Productos (solo ver), Clientes
"""

import os
import sys

# Así Python encuentra las carpetas datos/ y servicios/
_RAIZ = os.path.dirname(os.path.abspath(__file__))
if _RAIZ not in sys.path:
    sys.path.insert(0, _RAIZ)

import flet as ft

from datos.base_datos import inicializar
from servicios.logica import (
    ErrorMinimarket,
    actualizar_cliente,
    actualizar_producto,
    crear_cliente,
    crear_producto,
    crear_usuario,
    eliminar_cliente,
    eliminar_producto,
    listar_clientes,
    listar_productos,
    listar_usuarios,
    login,
    obtener_producto,
    permiso,
    productos_mas_vendidos,
    productos_stock_bajo,
    registrar_venta,
    total_vendido,
    ventas_del_dia,
)

# Color principal del minimarket (verde oscuro)
VERDE = ft.Colors.GREEN_800
VERDE_OSCURO = ft.Colors.GREEN_900
VERDE_SUAVE = ft.Colors.GREEN_50
FONDO = ft.Colors.GREY_100
RADIO = 16  # esquinas redondeadas, iguales en tarjetas y botones
ANCHO_LOGIN = 880  # a partir de este ancho, el login va en dos columnas


def en_bs(monto):
    """Formatea un número como precio en bolivianos, por ejemplo 8.50 Bs."""
    return f"{float(monto):.2f} Bs"


class MinimarketApp:
    """Guarda el estado de la pantalla: quién entró, en qué sección está y el carrito."""

    def __init__(self, page: ft.Page):
        self.page = page
        self.usuario = None  # diccionario que devuelve login(), o None
        self.indice = 0      # pestaña seleccionada del menú
        self.carrito = []    # lista de {"producto": ..., "cantidad": ...}
        self.busqueda = ""
        self._login_es_ancho = None  # para no redibujar el login en cada pixel

    # ----- avisos cortos (la barrita de abajo) -----

    def aviso(self, mensaje, ok=True):
        """Muestra un mensaje corto abajo de la pantalla."""
        self.page.show_dialog(
            ft.SnackBar(
                content=ft.Text(mensaje, color=ft.Colors.WHITE),
                bgcolor=VERDE if ok else ft.Colors.RED_700,
            )
        )

    def secciones(self):
        """Lista las secciones que puede ver el rol actual: (id, texto, icono)."""
        if self.usuario and self.usuario["rol"] == "admin":
            return [
                ("inicio", "Inicio", ft.Icons.HOME),
                ("productos", "Productos", ft.Icons.INVENTORY_2),
                ("clientes", "Clientes", ft.Icons.PEOPLE),
                ("ventas", "Ventas", ft.Icons.POINT_OF_SALE),
                ("reportes", "Reportes", ft.Icons.BAR_CHART),
                ("usuarios", "Usuarios", ft.Icons.MANAGE_ACCOUNTS),
            ]
        # El cajero empieza en Ventas y no ve reportes ni usuarios ni el inicio
        return [
            ("ventas", "Ventas", ft.Icons.POINT_OF_SALE),
            ("productos", "Productos", ft.Icons.INVENTORY_2),
            ("clientes", "Clientes", ft.Icons.PEOPLE),
        ]

    def seccion_actual(self):
        lista = self.secciones()
        if not lista:
            return "ventas"
        if self.indice < 0 or self.indice >= len(lista):
            self.indice = 0
        return lista[self.indice][0]

    # ----- dibujar la pantalla completa -----

    def _limpiar_pagina(self):
        """Saca la barra y los controles viejos, para que no quede nada suelto."""
        self.page.appbar = None
        try:
            self.page.clean()
        except Exception:
            self.page.controls.clear()

    def _es_ancho(self):
        """True si hay espacio para el login en dos columnas (escritorio)."""
        ancho = self.page.width or 0
        return ancho >= ANCHO_LOGIN

    def mostrar_login(self):
        """Dibuja la pantalla de inicio de sesión (dos columnas o una, según el ancho)."""
        self._limpiar_pagina()
        self._login_es_ancho = self._es_ancho()
        self.page.add(self._vista_login())
        self.page.update()

    def mostrar_principal(self):
        """Dibuja el menú y la sección en la que estamos."""
        nombre = self.usuario["nombre"]
        rol = self.usuario["rol"]
        # Barra de arriba, verde, con el botón de cerrar sesión
        self.page.appbar = ft.AppBar(
            leading=ft.Icon(ft.Icons.STOREFRONT, color=ft.Colors.WHITE),
            leading_width=40,
            title=ft.Text("Minimarket", size=18, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE),
            bgcolor=VERDE,
            color=ft.Colors.WHITE,
            toolbar_height=56,
            elevation=0,
            actions=[
                ft.Container(
                    padding=ft.Padding.only(right=8),
                    content=ft.Text(f"{nombre}  ({rol})", color=ft.Colors.WHITE, size=13),
                    alignment=ft.Alignment.CENTER,
                ),
                ft.IconButton(
                    icon=ft.Icons.LOGOUT,
                    icon_color=ft.Colors.WHITE,
                    tooltip="Cerrar sesión",
                    on_click=self._cerrar_sesion,
                ),
            ],
        )

        destinos = []
        for _sid, texto, icono in self.secciones():
            destinos.append(
                ft.NavigationRailDestination(icon=icono, label=texto)
            )

        rail = ft.NavigationRail(
            selected_index=self.indice,
            label_type=ft.NavigationRailLabelType.ALL,
            min_width=80,
            min_extended_width=180,
            extended=True,
            bgcolor=ft.Colors.WHITE,
            indicator_color=VERDE_SUAVE,
            selected_label_text_style=ft.TextStyle(color=VERDE, weight=ft.FontWeight.BOLD),
            destinations=destinos,
            on_change=self._cambiar_seccion,
        )

        cuerpo = ft.Container(
            expand=True,
            bgcolor=FONDO,
            padding=ft.Padding.all(20),
            content=self._cuerpo_seccion(),
        )

        self.page.controls.clear()
        self.page.add(
            ft.Row(
                expand=True,
                spacing=0,
                controls=[
                    rail,
                    ft.VerticalDivider(width=1, color=ft.Colors.GREY_300),
                    cuerpo,
                ],
            )
        )
        self.page.update()

    def refrescar(self):
        """Vuelve a dibujar la sección actual (después de guardar o borrar algo)."""
        if self.usuario:
            self.mostrar_principal()
        else:
            self.mostrar_login()

    def _cambiar_seccion(self, e):
        self.indice = e.control.selected_index
        self.busqueda = ""
        self.mostrar_principal()

    def _cerrar_sesion(self, e=None):
        self.usuario = None
        self.indice = 0
        self.carrito = []
        self.busqueda = ""
        self.mostrar_login()

    def _vineta(self, icono, texto):
        """Una línea del panel izquierdo: icono en un círculo + texto."""
        return ft.Row(
            spacing=14,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                ft.Container(
                    width=36,
                    height=36,
                    border_radius=18,
                    bgcolor=ft.Colors.with_opacity(0.16, ft.Colors.WHITE),
                    alignment=ft.Alignment.CENTER,
                    content=ft.Icon(icono, color=ft.Colors.WHITE, size=18),
                ),
                ft.Text(texto, color=ft.Colors.WHITE, size=14),
            ],
        )

    def _panel_marca(self):
        """
        Panel izquierdo de marca, al estilo de los logins de Shopify / Odoo:
        fondo verde, logo, lema y tres o cuatro ventajas del sistema.
        """
        return ft.Container(
            expand=4,
            clip_behavior=ft.ClipBehavior.HARD_EDGE,
            gradient=ft.LinearGradient(
                begin=ft.Alignment.TOP_LEFT,
                end=ft.Alignment.BOTTOM_RIGHT,
                colors=["#0B3D2E", VERDE_OSCURO, VERDE, ft.Colors.GREEN_600],
            ),
            padding=ft.Padding.symmetric(horizontal=48, vertical=48),
            content=ft.Column(
                expand=True,
                spacing=0,
                alignment=ft.MainAxisAlignment.CENTER,
                controls=[
                    ft.Container(
                        width=64,
                        height=64,
                        border_radius=16,
                        bgcolor=ft.Colors.WHITE,
                        alignment=ft.Alignment.CENTER,
                        content=ft.Icon(ft.Icons.STOREFRONT, size=34, color=VERDE),
                    ),
                    ft.Container(height=22),
                    ft.Text("Minimarket", size=36, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE),
                    ft.Container(height=8),
                    ft.Text(
                        "Sistema de ventas e inventario",
                        size=16,
                        color=ft.Colors.with_opacity(0.9, ft.Colors.WHITE),
                    ),
                    ft.Container(height=36),
                    self._vineta(ft.Icons.POINT_OF_SALE, "Caja rápida para registrar ventas"),
                    ft.Container(height=14),
                    self._vineta(ft.Icons.INVENTORY_2, "Inventario actualizado al momento"),
                    ft.Container(height=14),
                    self._vineta(ft.Icons.ADMIN_PANEL_SETTINGS, "Acceso por rol: admin o cajero"),
                    ft.Container(height=14),
                    self._vineta(ft.Icons.BAR_CHART, "Reportes claros del día"),
                ],
            ),
        )

    def _formulario_login(self):
        """
        El formulario blanco: título, usuario, contraseña, botón y pie.
        No tiene un ancho fijo enorme, para que en pantallas chicas no se desborde
        (eso era lo que hacía aparecer una segunda tarjeta / icono repetido).
        """
        campo_usuario = ft.TextField(
            label="Usuario",
            prefix_icon=ft.Icons.PERSON_OUTLINE,
            autofocus=True,
            filled=True,
            bgcolor=ft.Colors.GREY_50,
            border_radius=12,
            border_color=ft.Colors.GREY_300,
            focused_border_color=VERDE,
            on_submit=lambda e: intentar(),
        )
        campo_clave = ft.TextField(
            label="Contraseña",
            prefix_icon=ft.Icons.LOCK_OUTLINE,
            password=True,
            can_reveal_password=True,
            filled=True,
            bgcolor=ft.Colors.GREY_50,
            border_radius=12,
            border_color=ft.Colors.GREY_300,
            focused_border_color=VERDE,
            on_submit=lambda e: intentar(),
        )
        # Aviso de error: una franja, no un texto suelto
        texto_error = ft.Text(
            "Usuario o contraseña incorrectos.",
            color=ft.Colors.RED_800,
            size=13,
            expand=True,
        )
        banner_error = ft.Container(
            visible=False,
            bgcolor=ft.Colors.RED_50,
            border=ft.Border.all(width=1, color=ft.Colors.RED_200),
            border_radius=10,
            padding=ft.Padding.symmetric(horizontal=12, vertical=10),
            content=ft.Row(
                spacing=8,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Icon(ft.Icons.ERROR_OUTLINE, color=ft.Colors.RED_700, size=20),
                    texto_error,
                ],
            ),
        )

        def intentar(e=None):
            persona = login(campo_usuario.value or "", campo_clave.value or "")
            if persona is None:
                banner_error.visible = True
                campo_clave.value = ""
                self.page.update()
                return
            self.usuario = persona
            self.indice = 0
            self.carrito = []
            self.mostrar_principal()

        boton = ft.Button(
            content="Iniciar sesión",
            icon=ft.Icons.LOGIN,
            bgcolor=VERDE,
            color=ft.Colors.WHITE,
            height=48,
            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=12)),
            on_click=intentar,
        )

        # Credenciales de prueba, discretas (se ven al pasar el mouse)
        prueba = ft.Text(
            "Usuarios de prueba",
            size=12,
            color=ft.Colors.GREY_500,
            tooltip="admin / admin123\ncajero / cajero123",
            text_align=ft.TextAlign.CENTER,
        )

        pie = ft.Text(
            "© 2026 Minimarket",
            size=11,
            color=ft.Colors.GREY_500,
            text_align=ft.TextAlign.CENTER,
        )

        cuerpo = ft.Column(
            spacing=0,
            tight=True,
            horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
            controls=[
                ft.Text("Iniciar sesión", size=26, weight=ft.FontWeight.BOLD, color=ft.Colors.GREY_900),
                ft.Container(height=6),
                ft.Text(
                    "Ingresa con tu usuario de administrador o cajero",
                    size=13,
                    color=ft.Colors.GREY_600,
                ),
                ft.Container(height=22),
                campo_usuario,
                ft.Container(height=12),
                campo_clave,
                ft.Container(height=12),
                banner_error,
                ft.Container(height=8),
                boton,
                ft.Container(height=16),
                ft.Container(content=prueba, alignment=ft.Alignment.CENTER),
                ft.Container(height=20),
                ft.Container(content=pie, alignment=ft.Alignment.CENTER),
            ],
        )
        return cuerpo

    def _tarjeta_formulario(self):
        """La tarjeta blanca elevada que envuelve el formulario."""
        return ft.Container(
            width=420 if self._es_ancho() else None,
            bgcolor=ft.Colors.WHITE,
            border_radius=RADIO,
            padding=ft.Padding.symmetric(horizontal=36, vertical=36),
            shadow=ft.BoxShadow(
                blur_radius=28,
                spread_radius=0,
                color=ft.Colors.with_opacity(0.12, ft.Colors.BLACK),
                offset=ft.Offset(0, 8),
            ),
            clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
            content=self._formulario_login(),
        )

    def _vista_login(self):
        """Arma el login: dos columnas en escritorio, una tarjeta en móvil."""
        if self._es_ancho():
            # Escritorio: marca a la izquierda, formulario a la derecha
            return ft.Row(
                expand=True,
                spacing=0,
                vertical_alignment=ft.CrossAxisAlignment.STRETCH,
                controls=[
                    self._panel_marca(),
                    ft.Container(
                        expand=5,
                        bgcolor=FONDO,
                        alignment=ft.Alignment.CENTER,
                        padding=ft.Padding.all(40),
                        clip_behavior=ft.ClipBehavior.HARD_EDGE,
                        content=self._tarjeta_formulario(),
                    ),
                ],
            )

        # Móvil / ventana angosta: una sola tarjeta, sin desbordes
        # (el ancho fijo de 420 px era lo que repetía el icono abajo a la derecha)
        return ft.Container(
            expand=True,
            bgcolor=FONDO,
            clip_behavior=ft.ClipBehavior.HARD_EDGE,
            padding=ft.Padding.symmetric(horizontal=20, vertical=24),
            content=ft.Column(
                expand=True,
                scroll=ft.ScrollMode.AUTO,
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                spacing=16,
                controls=[
                    ft.Column(
                        spacing=6,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        tight=True,
                        controls=[
                            ft.Container(
                                width=56,
                                height=56,
                                border_radius=14,
                                bgcolor=VERDE,
                                alignment=ft.Alignment.CENTER,
                                content=ft.Icon(ft.Icons.STOREFRONT, size=30, color=ft.Colors.WHITE),
                            ),
                            ft.Text("Minimarket", size=22, weight=ft.FontWeight.BOLD, color=VERDE),
                            ft.Text(
                                "Sistema de ventas e inventario",
                                size=13,
                                color=ft.Colors.GREY_600,
                            ),
                        ],
                    ),
                    self._tarjeta_formulario(),
                ],
            ),
        )

    def _cuerpo_seccion(self):

        sid = self.seccion_actual()
        if sid == "inicio":
            return self._vista_inicio()
        if sid == "productos":
            return self._vista_productos()
        if sid == "clientes":
            return self._vista_clientes()
        if sid == "ventas":
            return self._vista_ventas()
        if sid == "reportes":
            return self._vista_reportes()
        if sid == "usuarios":
            return self._vista_usuarios()
        return ft.Text("Sección no encontrada.")

    # ----- 2) Inicio (solo admin): tarjetas con números del día -----

    def _tarjeta(self, titulo, valor, icono, color):
        # expand=True hace que las 4 tarjetas compartan el ancho de la fila
        return ft.Container(
            expand=True,
            content=ft.Card(
                elevation=1,
                shape=ft.RoundedRectangleBorder(radius=RADIO),
                clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
                content=ft.Container(
                    padding=ft.Padding.all(16),
                    content=ft.Column(
                        spacing=6,
                        controls=[
                            ft.Icon(icono, color=color, size=28),
                            ft.Text(titulo, size=13, color=ft.Colors.GREY_700),
                            ft.Text(str(valor), size=22, weight=ft.FontWeight.BOLD),
                        ],
                    ),
                ),
            ),
        )

    def _vista_inicio(self):
        ventas = ventas_del_dia()
        total = total_vendido()
        productos = listar_productos()
        bajos = productos_stock_bajo()

        alertas = []
        if not bajos:
            alertas.append(ft.Text("Todos los productos están bien de stock.", color=ft.Colors.GREY_700))
        else:
            for p in bajos:
                alertas.append(
                    ft.Text(
                        f"• {p['codigo']}  {p['nombre']}: quedan {p['stock']} (mínimo {p['stock_minimo']})",
                        color=ft.Colors.ORANGE_800,
                    )
                )

        return ft.Column(
            expand=True,
            scroll=ft.ScrollMode.AUTO,
            spacing=16,
            controls=[
                ft.Text("Inicio", size=24, weight=ft.FontWeight.BOLD, color=VERDE),
                ft.Text("Resumen de hoy", size=14, color=ft.Colors.GREY_700),
                ft.Row(
                    spacing=12,
                    controls=[
                        self._tarjeta("Ventas del día", len(ventas), ft.Icons.RECEIPT_LONG, VERDE),
                        self._tarjeta("Total vendido", en_bs(total), ft.Icons.PAYMENTS, VERDE),
                        self._tarjeta("Productos", len(productos), ft.Icons.INVENTORY_2, ft.Colors.BLUE_700),
                        self._tarjeta("Stock bajo", len(bajos), ft.Icons.WARNING, ft.Colors.ORANGE_800),
                    ],
                ),
                # La tarjeta de alertas ocupa todo el ancho, no solo el texto
                ft.Row(
                    controls=[
                        ft.Container(
                            expand=True,
                            content=ft.Card(
                                elevation=1,
                                shape=ft.RoundedRectangleBorder(radius=RADIO),
                                clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
                                content=ft.Container(
                                    padding=ft.Padding.all(16),
                                    content=ft.Column(
                                        spacing=8,
                                        controls=[
                                            ft.Text("Alertas de stock bajo", size=16, weight=ft.FontWeight.BOLD),
                                            *alertas,
                                        ],
                                    ),
                                ),
                            ),
                        )
                    ]
                ),
            ],
        )

    # ----- 3) Productos -----

    def _vista_productos(self):
        puede_editar = permiso(self.usuario["rol"], "crear_producto")
        texto = (self.busqueda or "").lower()
        lista = listar_productos()
        if texto:
            lista = [
                p for p in lista
                if texto in p["nombre"].lower()
                or texto in p["codigo"].lower()
                or texto in (p["categoria"] or "").lower()
            ]

        filas = []
        for p in lista:
            celdas = [
                ft.DataCell(ft.Text(p["codigo"])),
                ft.DataCell(ft.Text(p["nombre"])),
                ft.DataCell(ft.Text(p["categoria"] or "")),
                ft.DataCell(ft.Text(en_bs(p["precio"]))),
                ft.DataCell(ft.Text(str(p["stock"]))),
                ft.DataCell(ft.Text(str(p["stock_minimo"]))),
            ]
            if puede_editar:
                celdas.append(
                    ft.DataCell(
                        ft.Row(
                            spacing=0,
                            controls=[
                                ft.IconButton(
                                    icon=ft.Icons.EDIT,
                                    icon_color=VERDE,
                                    tooltip="Editar",
                                    data=p["id"],
                                    on_click=lambda e: self._dialogo_producto(e.control.data),
                                ),
                                ft.IconButton(
                                    icon=ft.Icons.DELETE,
                                    icon_color=ft.Colors.RED_700,
                                    tooltip="Eliminar",
                                    data=p["id"],
                                    on_click=lambda e: self._confirmar_borrar_producto(e.control.data),
                                ),
                            ],
                        )
                    )
                )
            filas.append(ft.DataRow(cells=celdas))

        columnas = [
            ft.DataColumn(label=ft.Text("Código")),
            ft.DataColumn(label=ft.Text("Nombre")),
            ft.DataColumn(label=ft.Text("Categoría")),
            ft.DataColumn(label=ft.Text("Precio")),
            ft.DataColumn(label=ft.Text("Stock")),
            ft.DataColumn(label=ft.Text("Mín.")),
        ]
        if puede_editar:
            columnas.append(ft.DataColumn(label=ft.Text("Acciones")))

        buscador = ft.TextField(
            label="Buscar producto",
            hint_text="Nombre, código o categoría",
            prefix_icon=ft.Icons.SEARCH,
            value=self.busqueda,
            expand=True,
            on_submit=self._cambiar_busqueda,
        )

        cabecera = [
            ft.Text("Productos", size=24, weight=ft.FontWeight.BOLD, color=VERDE),
            ft.Row(
                spacing=12,
                controls=[buscador]
                + (
                    [
                        ft.Button(
                            content="Agregar",
                            icon=ft.Icons.ADD,
                            bgcolor=VERDE,
                            color=ft.Colors.WHITE,
                            on_click=lambda e: self._dialogo_producto(None),
                        )
                    ]
                    if puede_editar
                    else []
                ),
            ),
        ]
        if not puede_editar:
            cabecera.append(ft.Text("Solo lectura: el cajero puede ver los productos, no cambiarlos.", size=12, color=ft.Colors.GREY_700))

        return ft.Column(
            expand=True,
            spacing=12,
            controls=cabecera
            + [
                ft.Container(
                    expand=True,
                    content=ft.Column(
                        expand=True,
                        scroll=ft.ScrollMode.AUTO,
                        controls=[
                            ft.DataTable(columns=columnas, rows=filas, heading_row_color=VERDE_SUAVE)
                            if filas
                            else ft.Text("No hay productos para mostrar.")
                        ],
                    ),
                )
            ],
        )

    def _cambiar_busqueda(self, e):
        self.busqueda = e.control.value or ""
        self.mostrar_principal()

    def _dialogo_producto(self, producto_id):
        actual = obtener_producto(producto_id=producto_id) if producto_id else None
        codigo = ft.TextField(label="Código", value=(actual["codigo"] if actual else ""), width=420)
        nombre = ft.TextField(label="Nombre", value=(actual["nombre"] if actual else ""), width=420)
        categoria = ft.TextField(label="Categoría", value=(actual["categoria"] if actual else ""), width=420)
        precio = ft.TextField(label="Precio (Bs)", value=(str(actual["precio"]) if actual else ""), width=420, keyboard_type=ft.KeyboardType.NUMBER)
        stock = ft.TextField(label="Stock", value=(str(actual["stock"]) if actual else "0"), width=420, keyboard_type=ft.KeyboardType.NUMBER)
        stock_minimo = ft.TextField(label="Stock mínimo", value=(str(actual["stock_minimo"]) if actual else "5"), width=420, keyboard_type=ft.KeyboardType.NUMBER)
        error = ft.Text("", color=ft.Colors.RED_700, visible=False)

        def guardar(e=None):
            try:
                if actual:
                    actualizar_producto(
                        self.usuario, producto_id, codigo.value, nombre.value,
                        categoria.value, precio.value, stock.value, stock_minimo.value,
                    )
                    msg = "Producto actualizado."
                else:
                    crear_producto(
                        self.usuario, codigo.value, nombre.value,
                        categoria.value, precio.value, stock.value, stock_minimo.value or 5,
                    )
                    msg = "Producto agregado."
                self.page.pop_dialog()
                self.aviso(msg)
                self.refrescar()
            except ErrorMinimarket as err:
                error.value = str(err)
                error.visible = True
                self.page.update()

        self.page.show_dialog(
            ft.AlertDialog(
                modal=True,
                title=ft.Text("Editar producto" if actual else "Agregar producto"),
                content=ft.Column(
                    tight=True,
                    width=440,
                    spacing=10,
                    scroll=ft.ScrollMode.AUTO,
                    controls=[codigo, nombre, categoria, precio, stock, stock_minimo, error],
                ),
                actions=[
                    ft.TextButton(content="Cancelar", on_click=lambda e: self.page.pop_dialog()),
                    ft.Button(content="Guardar", bgcolor=VERDE, color=ft.Colors.WHITE, on_click=guardar),
                ],
            )
        )

    def _confirmar_borrar_producto(self, producto_id):
        prod = obtener_producto(producto_id=producto_id)
        if prod is None:
            self.aviso("No se encontró ese producto.", ok=False)
            return

        def borrar(e=None):
            try:
                eliminar_producto(self.usuario, producto_id)
                self.page.pop_dialog()
                self.aviso("Producto eliminado.")
                self.refrescar()
            except ErrorMinimarket as err:
                self.page.pop_dialog()
                self.aviso(str(err), ok=False)

        self.page.show_dialog(
            ft.AlertDialog(
                modal=True,
                title=ft.Text("Eliminar producto"),
                content=ft.Text(f"¿Seguro que quieres eliminar '{prod['nombre']}'?"),
                actions=[
                    ft.TextButton(content="Cancelar", on_click=lambda e: self.page.pop_dialog()),
                    ft.Button(content="Eliminar", bgcolor=ft.Colors.RED_700, color=ft.Colors.WHITE, on_click=borrar),
                ],
            )
        )

    # ----- 4) Clientes -----

    def _vista_clientes(self):
        puede_editar = permiso(self.usuario["rol"], "editar_cliente")
        texto = (self.busqueda or "").lower()
        lista = listar_clientes()
        if texto:
            lista = [
                c for c in lista
                if texto in c["nombre"].lower()
                or texto in (c["ci_nit"] or "").lower()
                or texto in (c["telefono"] or "").lower()
            ]

        filas = []
        for c in lista:
            celdas = [
                ft.DataCell(ft.Text(str(c["id"]))),
                ft.DataCell(ft.Text(c["nombre"])),
                ft.DataCell(ft.Text(c["ci_nit"] or "")),
                ft.DataCell(ft.Text(c["telefono"] or "")),
            ]
            if puede_editar:
                celdas.append(
                    ft.DataCell(
                        ft.Row(
                            spacing=0,
                            controls=[
                                ft.IconButton(
                                    icon=ft.Icons.EDIT,
                                    icon_color=VERDE,
                                    tooltip="Editar",
                                    data=c["id"],
                                    on_click=lambda e: self._dialogo_cliente(e.control.data),
                                ),
                                ft.IconButton(
                                    icon=ft.Icons.DELETE,
                                    icon_color=ft.Colors.RED_700,
                                    tooltip="Eliminar",
                                    data=c["id"],
                                    on_click=lambda e: self._confirmar_borrar_cliente(e.control.data),
                                ),
                            ],
                        )
                    )
                )
            filas.append(ft.DataRow(cells=celdas))

        columnas = [
            ft.DataColumn(label=ft.Text("ID")),
            ft.DataColumn(label=ft.Text("Nombre")),
            ft.DataColumn(label=ft.Text("CI / NIT")),
            ft.DataColumn(label=ft.Text("Teléfono")),
        ]
        if puede_editar:
            columnas.append(ft.DataColumn(label=ft.Text("Acciones")))

        buscador = ft.TextField(
            label="Buscar cliente",
            hint_text="Nombre, CI/NIT o teléfono",
            prefix_icon=ft.Icons.SEARCH,
            value=self.busqueda,
            expand=True,
            on_submit=self._cambiar_busqueda,
        )

        return ft.Column(
            expand=True,
            spacing=12,
            controls=[
                ft.Text("Clientes", size=24, weight=ft.FontWeight.BOLD, color=VERDE),
                ft.Row(
                    spacing=12,
                    controls=[
                        buscador,
                        ft.Button(
                            content="Agregar",
                            icon=ft.Icons.ADD,
                            bgcolor=VERDE,
                            color=ft.Colors.WHITE,
                            on_click=lambda e: self._dialogo_cliente(None),
                        ),
                    ],
                ),
                ft.Container(
                    expand=True,
                    content=ft.Column(
                        expand=True,
                        scroll=ft.ScrollMode.AUTO,
                        controls=[
                            ft.DataTable(columns=columnas, rows=filas, heading_row_color=VERDE_SUAVE)
                            if filas
                            else ft.Text("No hay clientes para mostrar.")
                        ],
                    ),
                ),
            ],
        )

    def _dialogo_cliente(self, cliente_id):
        actual = None
        if cliente_id:
            for c in listar_clientes():
                if c["id"] == cliente_id:
                    actual = c
                    break
        nombre = ft.TextField(label="Nombre", value=(actual["nombre"] if actual else ""), width=420)
        ci = ft.TextField(label="CI / NIT", value=(actual["ci_nit"] if actual else ""), width=420)
        tel = ft.TextField(label="Teléfono", value=(actual["telefono"] if actual else ""), width=420)
        error = ft.Text("", color=ft.Colors.RED_700, visible=False)

        def guardar(e=None):
            try:
                if actual:
                    actualizar_cliente(self.usuario, cliente_id, nombre.value, ci.value, tel.value)
                    msg = "Cliente actualizado."
                else:
                    crear_cliente(self.usuario, nombre.value, ci.value, tel.value)
                    msg = "Cliente agregado."
                self.page.pop_dialog()
                self.aviso(msg)
                self.refrescar()
            except ErrorMinimarket as err:
                error.value = str(err)
                error.visible = True
                self.page.update()

        self.page.show_dialog(
            ft.AlertDialog(
                modal=True,
                title=ft.Text("Editar cliente" if actual else "Agregar cliente"),
                content=ft.Column(
                    tight=True,
                    width=440,
                    spacing=10,
                    controls=[nombre, ci, tel, error],
                ),
                actions=[
                    ft.TextButton(content="Cancelar", on_click=lambda e: self.page.pop_dialog()),
                    ft.Button(content="Guardar", bgcolor=VERDE, color=ft.Colors.WHITE, on_click=guardar),
                ],
            )
        )

    def _confirmar_borrar_cliente(self, cliente_id):
        actual = None
        for c in listar_clientes():
            if c["id"] == cliente_id:
                actual = c
                break
        if actual is None:
            self.aviso("No se encontró ese cliente.", ok=False)
            return

        def borrar(e=None):
            try:
                eliminar_cliente(self.usuario, cliente_id)
                self.page.pop_dialog()
                self.aviso("Cliente eliminado.")
                self.refrescar()
            except ErrorMinimarket as err:
                self.page.pop_dialog()
                self.aviso(str(err), ok=False)

        self.page.show_dialog(
            ft.AlertDialog(
                modal=True,
                title=ft.Text("Eliminar cliente"),
                content=ft.Text(f"¿Seguro que quieres eliminar a '{actual['nombre']}'?"),
                actions=[
                    ft.TextButton(content="Cancelar", on_click=lambda e: self.page.pop_dialog()),
                    ft.Button(content="Eliminar", bgcolor=ft.Colors.RED_700, color=ft.Colors.WHITE, on_click=borrar),
                ],
            )
        )

    # ----- 5) Ventas (carrito) -----

    def _vista_ventas(self):
        productos = listar_productos()
        clientes = listar_clientes()

        opciones_prod = [
            ft.DropdownOption(key=str(p["id"]), text=f"{p['codigo']} — {p['nombre']}  ({en_bs(p['precio'])}, stock {p['stock']})")
            for p in productos
        ]
        combo_prod = ft.Dropdown(label="Producto", options=opciones_prod, expand=True)
        cant = ft.TextField(label="Cantidad", value="1", width=120, keyboard_type=ft.KeyboardType.NUMBER)

        opciones_cli = [ft.DropdownOption(key="0", text="Consumidor final")]
        for c in clientes:
            opciones_cli.append(ft.DropdownOption(key=str(c["id"]), text=f"{c['nombre']}  ({c['ci_nit'] or 's/CI'})"))
        combo_cli = ft.Dropdown(label="Cliente (opcional)", options=opciones_cli, value="0", width=280)

        def agregar(e=None):
            if not combo_prod.value:
                self.aviso("Elige un producto.", ok=False)
                return
            try:
                cantidad = int(cant.value)
            except (TypeError, ValueError):
                self.aviso("La cantidad debe ser un número entero.", ok=False)
                return
            if cantidad <= 0:
                self.aviso("La cantidad debe ser mayor que cero.", ok=False)
                return
            prod = obtener_producto(producto_id=int(combo_prod.value))
            if prod is None:
                self.aviso("No se encontró ese producto.", ok=False)
                return
            # Si el producto ya está en el carrito, sumamos la cantidad
            ya = 0
            for item in self.carrito:
                if item["producto"]["id"] == prod["id"]:
                    ya = item["cantidad"]
                    break
            if ya + cantidad > prod["stock"]:
                self.aviso(
                    f"No hay suficiente stock de '{prod['nombre']}'. Hay {prod['stock']}.",
                    ok=False,
                )
                return
            if ya:
                for item in self.carrito:
                    if item["producto"]["id"] == prod["id"]:
                        item["cantidad"] += cantidad
                        break
            else:
                self.carrito.append({"producto": prod, "cantidad": cantidad})
            cant.value = "1"
            self.mostrar_principal()

        def quitar(producto_id):
            self.carrito = [i for i in self.carrito if i["producto"]["id"] != producto_id]
            self.mostrar_principal()

        filas_carrito = []
        total = 0.0
        for item in self.carrito:
            p = item["producto"]
            sub = round(float(p["precio"]) * item["cantidad"], 2)
            total += sub
            filas_carrito.append(
                ft.DataRow(
                    cells=[
                        ft.DataCell(ft.Text(p["codigo"])),
                        ft.DataCell(ft.Text(p["nombre"])),
                        ft.DataCell(ft.Text(str(item["cantidad"]))),
                        ft.DataCell(ft.Text(en_bs(p["precio"]))),
                        ft.DataCell(ft.Text(en_bs(sub))),
                        ft.DataCell(
                            ft.IconButton(
                                icon=ft.Icons.CLOSE,
                                icon_color=ft.Colors.RED_700,
                                tooltip="Quitar",
                                data=p["id"],
                                on_click=lambda e: quitar(e.control.data),
                            )
                        ),
                    ]
                )
            )

        def confirmar(e=None):
            if not self.carrito:
                self.aviso("El carrito está vacío. Agrega al menos un producto.", ok=False)
                return
            cliente_id = None
            if combo_cli.value and combo_cli.value != "0":
                cliente_id = int(combo_cli.value)
            items = [
                {"producto_id": i["producto"]["id"], "cantidad": i["cantidad"]}
                for i in self.carrito
            ]
            try:
                venta = registrar_venta(self.usuario["id"], cliente_id, items)
            except ErrorMinimarket as err:
                self.aviso(str(err), ok=False)
                return
            self.carrito = []
            self._mostrar_ticket(venta)

        return ft.Column(
            expand=True,
            spacing=12,
            controls=[
                ft.Text("Nueva venta", size=24, weight=ft.FontWeight.BOLD, color=VERDE),
                ft.Row(
                    spacing=12,
                    vertical_alignment=ft.CrossAxisAlignment.END,
                    controls=[combo_prod, cant, ft.Button(content="Agregar al carrito", icon=ft.Icons.ADD_SHOPPING_CART, bgcolor=VERDE, color=ft.Colors.WHITE, on_click=agregar)],
                ),
                ft.Row(controls=[combo_cli]),
                ft.Container(
                    expand=True,
                    content=ft.Column(
                        expand=True,
                        scroll=ft.ScrollMode.AUTO,
                        controls=[
                            ft.DataTable(
                                heading_row_color=VERDE_SUAVE,
                                columns=[
                                    ft.DataColumn(label=ft.Text("Código")),
                                    ft.DataColumn(label=ft.Text("Producto")),
                                    ft.DataColumn(label=ft.Text("Cant.")),
                                    ft.DataColumn(label=ft.Text("Precio")),
                                    ft.DataColumn(label=ft.Text("Subtotal")),
                                    ft.DataColumn(label=ft.Text("")),
                                ],
                                rows=filas_carrito,
                            )
                            if filas_carrito
                            else ft.Text("El carrito está vacío.")
                        ],
                    ),
                ),
                ft.Row(
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    controls=[
                        ft.Text(f"TOTAL: {en_bs(total)}", size=22, weight=ft.FontWeight.BOLD, color=VERDE),
                        ft.Button(
                            content="Confirmar venta",
                            icon=ft.Icons.CHECK,
                            bgcolor=VERDE if self.carrito else ft.Colors.GREY_400,
                            color=ft.Colors.WHITE,
                            disabled=not self.carrito,
                            on_click=confirmar,
                        ),
                    ],
                ),
            ],
        )

    def _mostrar_ticket(self, venta):
        """Muestra el recibo de la venta que acaba de registrarse."""
        cliente = venta.get("cliente_nombre") or "Consumidor final"
        lineas = [
            ft.Text(f"Venta N° {venta['id']}", size=18, weight=ft.FontWeight.BOLD),
            ft.Text(venta["fecha"]),
            ft.Text(f"Cliente: {cliente}"),
            ft.Text(f"Atendido por: {venta['usuario_nombre']}"),
            ft.Divider(),
        ]
        for d in venta["detalle"]:
            lineas.append(
                ft.Text(
                    f"{d['cantidad']} x {d['nombre']}  ({en_bs(d['precio_unitario'])})  =  {en_bs(d['subtotal'])}"
                )
            )
        lineas.append(ft.Divider())
        lineas.append(ft.Text(f"TOTAL: {en_bs(venta['total'])}", size=20, weight=ft.FontWeight.BOLD, color=VERDE))

        def cerrar(e=None):
            self.page.pop_dialog()
            self.refrescar()

        self.page.show_dialog(
            ft.AlertDialog(
                modal=True,
                title=ft.Text("Ticket de venta"),
                content=ft.Column(tight=True, width=420, spacing=6, controls=lineas),
                actions=[ft.Button(content="Cerrar", bgcolor=VERDE, color=ft.Colors.WHITE, on_click=cerrar)],
            )
        )

    # ----- 6) Reportes (solo admin) -----

    def _vista_reportes(self):
        ventas = ventas_del_dia()
        total = total_vendido()
        mas = productos_mas_vendidos()
        bajos = productos_stock_bajo()

        filas_ventas = [
            ft.DataRow(
                cells=[
                    ft.DataCell(ft.Text(str(v["id"]))),
                    ft.DataCell(ft.Text(v["fecha"])),
                    ft.DataCell(ft.Text(v.get("cliente_nombre") or "Consumidor final")),
                    ft.DataCell(ft.Text(v["usuario_nombre"])),
                    ft.DataCell(ft.Text(en_bs(v["total"]))),
                ]
            )
            for v in ventas
        ]
        filas_mas = [
            ft.DataRow(
                cells=[
                    ft.DataCell(ft.Text(p["codigo"])),
                    ft.DataCell(ft.Text(p["nombre"])),
                    ft.DataCell(ft.Text(str(p["cantidad_vendida"]))),
                    ft.DataCell(ft.Text(en_bs(p["total"]))),
                ]
            )
            for p in mas
        ]
        filas_bajos = [
            ft.DataRow(
                cells=[
                    ft.DataCell(ft.Text(p["codigo"])),
                    ft.DataCell(ft.Text(p["nombre"])),
                    ft.DataCell(ft.Text(str(p["stock"]))),
                    ft.DataCell(ft.Text(str(p["stock_minimo"]))),
                ]
            )
            for p in bajos
        ]

        return ft.Column(
            expand=True,
            scroll=ft.ScrollMode.AUTO,
            spacing=16,
            controls=[
                ft.Text("Reportes", size=24, weight=ft.FontWeight.BOLD, color=VERDE),
                ft.Row(
                    wrap=True,
                    spacing=12,
                    controls=[
                        self._tarjeta("Ventas de hoy", len(ventas), ft.Icons.RECEIPT_LONG, VERDE),
                        self._tarjeta("Total de hoy", en_bs(total), ft.Icons.PAYMENTS, VERDE),
                    ],
                ),
                ft.Text("Ventas del día", size=16, weight=ft.FontWeight.BOLD),
                ft.DataTable(
                    heading_row_color=VERDE_SUAVE,
                    columns=[
                        ft.DataColumn(label=ft.Text("N°")),
                        ft.DataColumn(label=ft.Text("Fecha")),
                        ft.DataColumn(label=ft.Text("Cliente")),
                        ft.DataColumn(label=ft.Text("Usuario")),
                        ft.DataColumn(label=ft.Text("Total")),
                    ],
                    rows=filas_ventas,
                )
                if filas_ventas
                else ft.Text("Hoy todavía no hay ventas."),
                ft.Text("Productos más vendidos", size=16, weight=ft.FontWeight.BOLD),
                ft.DataTable(
                    heading_row_color=VERDE_SUAVE,
                    columns=[
                        ft.DataColumn(label=ft.Text("Código")),
                        ft.DataColumn(label=ft.Text("Producto")),
                        ft.DataColumn(label=ft.Text("Cantidad")),
                        ft.DataColumn(label=ft.Text("Total")),
                    ],
                    rows=filas_mas,
                )
                if filas_mas
                else ft.Text("Todavía no hay ventas."),
                ft.Text("Productos con stock bajo", size=16, weight=ft.FontWeight.BOLD),
                ft.DataTable(
                    heading_row_color=VERDE_SUAVE,
                    columns=[
                        ft.DataColumn(label=ft.Text("Código")),
                        ft.DataColumn(label=ft.Text("Producto")),
                        ft.DataColumn(label=ft.Text("Stock")),
                        ft.DataColumn(label=ft.Text("Mínimo")),
                    ],
                    rows=filas_bajos,
                )
                if filas_bajos
                else ft.Text("Todos los productos están bien de stock."),
            ],
        )

    # ----- 7) Usuarios (solo admin) -----

    def _vista_usuarios(self):
        try:
            lista = listar_usuarios(self.usuario)
        except ErrorMinimarket as err:
            return ft.Text(str(err), color=ft.Colors.RED_700)

        filas = [
            ft.DataRow(
                cells=[
                    ft.DataCell(ft.Text(str(u["id"]))),
                    ft.DataCell(ft.Text(u["usuario"])),
                    ft.DataCell(ft.Text(u["nombre"])),
                    ft.DataCell(ft.Text(u["rol"])),
                    ft.DataCell(ft.Text("Activo" if u["activo"] else "Inactivo")),
                ]
            )
            for u in lista
        ]
        return ft.Column(
            expand=True,
            spacing=12,
            controls=[
                ft.Text("Usuarios", size=24, weight=ft.FontWeight.BOLD, color=VERDE),
                ft.Row(
                    alignment=ft.MainAxisAlignment.END,
                    controls=[
                        ft.Button(
                            content="Crear usuario",
                            icon=ft.Icons.PERSON_ADD,
                            bgcolor=VERDE,
                            color=ft.Colors.WHITE,
                            on_click=lambda e: self._dialogo_usuario(),
                        )
                    ],
                ),
                ft.DataTable(
                    heading_row_color=VERDE_SUAVE,
                    columns=[
                        ft.DataColumn(label=ft.Text("ID")),
                        ft.DataColumn(label=ft.Text("Usuario")),
                        ft.DataColumn(label=ft.Text("Nombre")),
                        ft.DataColumn(label=ft.Text("Rol")),
                        ft.DataColumn(label=ft.Text("Estado")),
                    ],
                    rows=filas,
                ),
            ],
        )

    def _dialogo_usuario(self):
        campo_usuario = ft.TextField(label="Nombre de usuario", width=420)
        campo_clave = ft.TextField(label="Contraseña", password=True, can_reveal_password=True, width=420)
        campo_nombre = ft.TextField(label="Nombre de la persona", width=420)
        campo_rol = ft.Dropdown(
            label="Rol",
            width=420,
            value="cajero",
            options=[
                ft.DropdownOption(key="cajero", text="Cajero"),
                ft.DropdownOption(key="admin", text="Administrador"),
            ],
        )
        error = ft.Text("", color=ft.Colors.RED_700, visible=False)

        def guardar(e=None):
            try:
                nuevo = crear_usuario(
                    self.usuario,
                    campo_usuario.value,
                    campo_clave.value,
                    campo_nombre.value,
                    campo_rol.value,
                )
                self.page.pop_dialog()
                self.aviso(f"Usuario '{nuevo['usuario']}' creado con rol {nuevo['rol']}.")
                self.refrescar()
            except ErrorMinimarket as err:
                error.value = str(err)
                error.visible = True
                self.page.update()

        self.page.show_dialog(
            ft.AlertDialog(
                modal=True,
                title=ft.Text("Crear usuario"),
                content=ft.Column(
                    tight=True,
                    width=440,
                    spacing=10,
                    controls=[campo_usuario, campo_clave, campo_nombre, campo_rol, error],
                ),
                actions=[
                    ft.TextButton(content="Cancelar", on_click=lambda e: self.page.pop_dialog()),
                    ft.Button(content="Crear", bgcolor=VERDE, color=ft.Colors.WHITE, on_click=guardar),
                ],
            )
        )


def main(page: ft.Page):
    """Punto de entrada de Flet: configura la ventana y muestra el login."""
    inicializar()  # crea la base de datos y los datos de ejemplo, si hace falta

    page.title = "Minimarket"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.theme = ft.Theme(
        color_scheme_seed=ft.Colors.GREEN,
        card_theme=ft.CardTheme(
            elevation=1,
            shape=ft.RoundedRectangleBorder(radius=RADIO),
            clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
        ),
    )
    page.bgcolor = FONDO
    page.padding = 0

    # Tamaño inicial de la ventana (en la versión web esto se ignora)
    try:
        page.window.width = 1150
        page.window.height = 740
        page.window.min_width = 400
        page.window.min_height = 560
    except Exception:
        pass

    app = MinimarketApp(page)

    def al_redimensionar(e=None):
        # Solo redibuja el login si cruza el punto de "ancho / angosto"
        if app.usuario is None and app._login_es_ancho is not None:
            if app._es_ancho() != app._login_es_ancho:
                app.mostrar_login()

    page.on_resize = al_redimensionar
    app.mostrar_login()


if __name__ == "__main__":
    ft.run(main)
